# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

def mesh_triangulate(me):
    import bmesh
    bm = bmesh.new()
    bm.from_mesh(me)
    bmesh.ops.triangulate(bm, faces=bm.faces)
    bm.to_mesh(me)
    bm.free()

def export_pcghg(verts, faces, strips, mesh_verts, filepath):
    from struct import pack

    # Model Bytes
    modelBytes = bytearray()

    # Header
    modelBytes.extend(bytearray("BactaTank\0",'utf-8'))
    modelBytes.extend(bytearray("PCGHG\0",'utf-8'))
    modelBytes.extend(pack("f", 0.2))

    # Material data probably
    modelBytes.extend(bytearray("Materials\0",'utf-8'))
    modelBytes.extend(pack("i", 0)) # Material Count
    #fw(pack("I", 33556745))

    # Mesh Data
    modelBytes.extend(bytearray("Meshes\0",'utf-8'))
    modelBytes.extend(pack("i", 1)) # Mesh Count

    # Mesh Data
    modelBytes.extend(bytearray("MeshData\0",'utf-8'))
    modelBytes.extend(pack("I", len(strips) - 2))
    modelBytes.extend(pack("I", len(verts)))
    modelBytes.extend(bytearray("MeshAttributes\0",'utf-8'))
    modelBytes.extend(pack("I", 4))
    modelBytes.extend(bytearray("Position\0",'utf-8'))
    modelBytes.extend(bytearray("Normal\0",'utf-8'))
    modelBytes.extend(bytearray("Colour\0",'utf-8'))
    modelBytes.extend(bytearray("UV\0",'utf-8'))

    # Vertex buffer
    # ---------------------------

    modelBytes.extend(bytearray("VertexBuffer\0",'utf-8'))
    modelBytes.extend(bytearray("Position\0",'utf-8'))

    for index, normal, uv_coords in verts:
        # Position
        modelBytes.extend(pack("f", -mesh_verts[index].co[0]))
        modelBytes.extend(pack("f", mesh_verts[index].co[1]))
        modelBytes.extend(pack("f", mesh_verts[index].co[2]))

    modelBytes.extend(bytearray("Normal\0",'utf-8'))
    
    for index, normal, uv_coords in verts:
        # Normal
        modelBytes.extend(pack("B", int((float(normal[0]) + 1) * 127.5)))
        modelBytes.extend(pack("B", 255 - int((float(normal[1]) + 1) * 127.5)))
        modelBytes.extend(pack("B", 255 - int((float(normal[2]) + 1) * 127.5)))
        modelBytes.extend(pack("B", 0))

    modelBytes.extend(bytearray("Colour\0",'utf-8'))
    
    for index, normal, uv_coords in verts:
        # Colour
        modelBytes.extend(pack("B", 127))
        modelBytes.extend(pack("B", 127))
        modelBytes.extend(pack("B", 127))
        modelBytes.extend(pack("B", 127))
        
    modelBytes.extend(bytearray("UV\0",'utf-8'))
    
    for index, normal, uv_coords in verts:
        # UV Coords
        modelBytes.extend(pack("<2f", *uv_coords))

    # Index buffer
    # ---------------------------
    
    modelBytes.extend(bytearray("IndexBuffer\0",'utf-8'))
    modelBytes.extend(pack("I", len(strips)*2))

    for pf in strips:
        modelBytes.extend(pack("h", pf))

    with open(filepath, "wb") as file:
        file.write(modelBytes)

def save_mesh(filepath, mesh, export_skinning, export_version):
    import bpy
    from . import tristrip

    def rvec3d(v):
        return round(v[0], 6), round(v[1], 6), round(v[2], 6)

    def rvec2d(v):
        return round(v[0], 6), round(v[1], 6)

    active_uv_layer = mesh.uv_layers.active.data

    if mesh.vertex_colors:
        active_col_layer = mesh.vertex_colors.active.data
    else:
        use_colors = False

    # in case
    color = uvcoord = uvcoord_key = normal = normal_key = None

    mesh_verts = mesh.vertices
    # vdict = {} # (index, normal, uv) -> new index
    vdict = [{} for i in range(len(mesh_verts))]
    ttm_verts = []
    ttm_uvs = []
    ttm_faces = [[] for f in range(len(mesh.polygons))]
    vert_count = 0

    for i, f in enumerate(mesh.polygons):

        smooth = f.use_smooth
        if not smooth:
            normal = f.normal[:]
            normal_key = rvec3d(normal)

        uv = [
            active_uv_layer[l].uv[:]
            for l in range(f.loop_start, f.loop_start + f.loop_total)
        ]

        pf = ttm_faces[i]
        for j, vidx in enumerate(f.vertices):
            v = mesh_verts[vidx]

            if smooth:
                normal = v.normal[:]
                normal_key = rvec3d(normal)

            uvcoord = uv[j][0], 1-uv[j][1]
            uvcoord_key = rvec2d(uvcoord)

            key = normal_key, uvcoord_key,

            vdict_local = vdict[vidx]
            pf_vidx = vdict_local.get(key)  # Will be None initially

            if pf_vidx is None:  # Same as vdict_local.has_key(key)
                pf_vidx = vdict_local[key] = vert_count
                ttm_verts.append((vidx, normal, uvcoord))
                vert_count += 1

            pf.append(pf_vidx)

    ttm_strips = tristrip.stripify(ttm_faces, stitchstrips=True)[0]
    export_pcghg(ttm_verts, ttm_faces, ttm_strips, mesh_verts, filepath)


def save(
    context,
    filepath="",
    export_skinning=False,
    use_selection=False,
    use_mesh_modifiers=True,
    export_version=None,
    global_matrix=None,
):
    import time
    import bpy
    import bmesh

    t = time.time()

    if bpy.ops.object.mode_set.poll():
        bpy.ops.object.mode_set(mode='OBJECT')

    if use_selection:
        obs = context.selected_objects
    else:
        obs = context.scene.objects

    depsgraph = context.evaluated_depsgraph_get()
    bm = bmesh.new()

    for ob in obs:
        if use_mesh_modifiers:
            ob_eval = ob.evaluated_get(depsgraph)
        else:
            ob_eval = ob

        try:
            me = ob_eval.to_mesh()
        except RuntimeError:
            continue

        me.transform(ob.matrix_world)
        bm.from_mesh(me)
        ob_eval.to_mesh_clear()

    mesh = bpy.data.meshes.new("TMP PLY EXPORT")
    bm.to_mesh(mesh)
    bm.free()

    if global_matrix is not None:
        mesh.transform(global_matrix)

    mesh.calc_normals()
    mesh.flip_normals()

    mesh_triangulate(mesh)

    save_mesh(
        filepath,
        mesh,
        export_skinning,
        export_version,
    )

    bpy.data.meshes.remove(mesh)

    t_delta = time.time() - t
    print(f"Export completed {filepath!r} in {t_delta:.3f}")
