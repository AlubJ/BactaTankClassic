def load_ttm(filepath):
    import time
    import bpy
    from struct import unpack, unpack_from
    import math

    t = time.time()
    ttm_name = bpy.path.display_name_from_filepath(filepath)

    offset = 0

    # BactaTank and PCGHG
    data = bytearray()
    with open(filepath, 'rb') as file:
        data = file.read()
    offset += 16

    # Check version is 0.1
    version = unpack_from("f", data, offset)[0]
    #if version != 0.1:
        #return {'CANCELLED'}

    offset += 38

    triangleCount = unpack_from("i", data, offset)[0]
    vertexCount = unpack_from("i", data, offset + 4)[0]

    #print(vertexSize)
    #print(triangleCount)

    offset += 75

    vertices = []
    normals = []
    uvs = []
    #print(vertexCount)
    #print(offset)

    for i in range(vertexCount):
        vertex = [0, 0, 0]
        vertex[0] = -unpack_from("f", data, offset)[0]
        vertex[1] = unpack_from("f", data, offset + 4)[0]
        vertex[2] = unpack_from("f", data, offset + 8)[0]
        offset += 12
        vertices.append(vertex)
    offset+=7
    for i in range(vertexCount):
        normal = [0, 0, 0]
        normal[0] = ((unpack_from("B", data, offset + 0)[0]/255)*2)-1
        normal[0] = ((unpack_from("B", data, offset + 1)[0]/255)*2)-1
        normal[0] = ((unpack_from("B", data, offset + 2)[0]/255)*2)-1
        offset += 4
        normals.append(normal)
    offset+=7
    for i in range(vertexCount):
        offset += 4
    offset+=3
    for i in range(vertexCount):
        tex = [0, 0]
        tex[0] = unpack_from("f", data, offset + 0)[0]
        tex[1] = unpack_from("f", data, offset + 4)[0]
        offset += 8
        uvs.append(tex)

    #print (offset)
    offset += 16
    
    triangles = []
    for i in range(triangleCount+2):
        triangles.append(unpack_from("H", data, offset)[0])
        offset += 2
    #print(triangles)
        
    from . import tristrip
    
    triangles = tristrip.triangulate([triangles])
    
    edges = []

    mesh = bpy.data.meshes.new("myBeautifulMesh")
    mesh.from_pydata(vertices, edges, triangles)
    mesh.update()

    for ob in bpy.context.selected_objects:
        ob.select_set(False)
    
    import bmesh

    obj = bpy.data.objects.new(ttm_name, mesh)
    bpy.context.collection.objects.link(obj)
    bpy.context.view_layer.objects.active = obj
    obj.select_set(True)
    bpy.context.active_object.rotation_euler[0] = math.radians(90)

    mesh = obj.data
    for f in mesh.polygons:
        f.use_smooth = True

    print("\nSuccessfully imported %r in %.3f sec" % (filepath, time.time() - t))

    return {'FINISHED'}


def load(operator, context, filepath=""):
    return load_ttm(filepath)