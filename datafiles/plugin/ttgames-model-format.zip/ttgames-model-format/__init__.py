# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# <pep8-80 compliant>

bl_info = {
    "name": "BactaTank Import Format",
    "author": "Alub",
    "version": (2, 1, 0),
    "blender": (2, 90, 0),
    "location": "File > Import/Export",
    "description": "Import-Export TTGames mesh data for use in BactaTank",
    "doc_url": "",
    "support": 'COMMUNITY',
    "category": "Import-Export",
}

if "bpy" in locals():
    import importlib
    if "export_ttm" in locals():
        importlib.reload(export_ttm)
    if "import_ttm" in locals():
        importlib.reload(import_ttm)


import bpy
from bpy.props import (
    CollectionProperty,
    StringProperty,
    BoolProperty,
    FloatProperty,
    EnumProperty,
)
from bpy_extras.io_utils import (
    ImportHelper,
    ExportHelper,
    axis_conversion,
    orientation_helper,
)

@orientation_helper(axis_forward='-Z', axis_up='Y')
class ImportTTM(bpy.types.Operator, ImportHelper):
    """Load a TTM geometry file"""
    bl_idname = "import_mesh.btank"
    bl_label = "Import BactaTank"
    bl_options = {'UNDO'}

    files: CollectionProperty(
        name="File Path",
        description="File path used for importing the BactaTank file",
        type=bpy.types.OperatorFileListElement,
    )

    # Hide opertator properties, rest of this is managed in C. See WM_operator_properties_filesel().
    hide_props_region: BoolProperty(
        name="Hide Operator Properties",
        description="Collapse the region displaying the operator settings",
        default=True,
    )

    directory: StringProperty()

    filename_ext = ".btank"
    filter_glob: StringProperty(default="*.btank", options={'HIDDEN'})

    def execute(self, context):
        import os
        from . import import_ttm

        context.window.cursor_set('WAIT')

        paths = [
            os.path.join(self.directory, name.name)
            for name in self.files
        ]

        if not paths:
            paths.append(self.filepath)

        for path in paths:
            import_ttm.load(self, context, path)

        context.window.cursor_set('DEFAULT')

        return {'FINISHED'}


@orientation_helper(axis_forward='-Z', axis_up='Y')
class ExportTTM(bpy.types.Operator, ExportHelper):
    bl_idname = "export_mesh.btank"
    bl_label = "Export BactaTank"
    bl_description = "Export mesh for use in BactaTank"

    filename_ext = ".btank"
    filter_glob: StringProperty(default="*.btank", options={'HIDDEN'})

    export_skinning: BoolProperty(
        name="Export Skinning",
        description="Export the skinning information",
    )
    use_selection: BoolProperty(
        name="Selection Only",
        description="Export selected objects only",
        default=False,
    )
    use_mesh_modifiers: BoolProperty(
        name="Apply Modifiers",
        description="Apply Modifiers to the exported mesh",
        default=True,
    )
    export_version: EnumProperty(
        name="Export Version",
        description="What version of TTGames Mesh to export to.",
        items=[
            #("hgo", "HGO/NUP", "Export to HGO/NUP Version", 0),
            ("pcghg", "PCGHG", "Export to PCGHG Version", 0),
            #("nxglij2", "NXG-LIJ2", "Export to NXG Version", 1),
            #("dx11", "DX11", "Export to DX11 Version", 3),
        ],
        default="pcghg",
    )

    def execute(self, context):
        from mathutils import Matrix
        from . import export_ttm

        context.window.cursor_set('WAIT')

        keywords = self.as_keywords(
            ignore=(
                "axis_forward",
                "axis_up",
                "global_scale",
                "check_existing",
                "filter_glob",
            )
        )
        global_matrix = axis_conversion(
            to_forward=self.axis_forward,
            to_up=self.axis_up,
        ).to_4x4() @ Matrix.Scale(1, 4)
        keywords["global_matrix"] = global_matrix

        export_ttm.save(context, **keywords)

        context.window.cursor_set('DEFAULT')

        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        sfile = context.space_data
        operator = sfile.active_operator

        col = layout.column(heading="Options")
        col.prop(operator, "export_skinning")
        col.prop(operator, "use_selection")
        col.prop(operator, "use_mesh_modifiers")
        col.prop(operator, "export_version")


def menu_func_import(self, context):
    self.layout.operator(ImportTTM.bl_idname, text="BactaTank Mesh (.btank)")


def menu_func_export(self, context):
    self.layout.operator(ExportTTM.bl_idname, text="BactaTank Mesh (.btank)")


classes = (
    ImportTTM,
    ExportTTM,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)

    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)


if __name__ == "__main__":
    register()
